-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 06-10-2025 a las 00:33:33
-- Versión del servidor: 9.1.0
-- Versión de PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `forneria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add content type', 4, 'add_contenttype'),
(14, 'Can change content type', 4, 'change_contenttype'),
(15, 'Can delete content type', 4, 'delete_contenttype'),
(16, 'Can view content type', 4, 'view_contenttype'),
(17, 'Can add session', 5, 'add_session'),
(18, 'Can change session', 5, 'change_session'),
(19, 'Can delete session', 5, 'delete_session'),
(20, 'Can view session', 5, 'view_session'),
(21, 'Can add usuario', 6, 'add_usuario'),
(22, 'Can change usuario', 6, 'change_usuario'),
(23, 'Can delete usuario', 6, 'delete_usuario'),
(24, 'Can view usuario', 6, 'view_usuario'),
(25, 'Can add categoria', 7, 'add_categoria'),
(26, 'Can change categoria', 7, 'change_categoria'),
(27, 'Can delete categoria', 7, 'delete_categoria'),
(28, 'Can view categoria', 7, 'view_categoria'),
(29, 'Can add cliente', 8, 'add_cliente'),
(30, 'Can change cliente', 8, 'change_cliente'),
(31, 'Can delete cliente', 8, 'delete_cliente'),
(32, 'Can view cliente', 8, 'view_cliente'),
(33, 'Can add detalle venta', 9, 'add_detalleventa'),
(34, 'Can change detalle venta', 9, 'change_detalleventa'),
(35, 'Can delete detalle venta', 9, 'delete_detalleventa'),
(36, 'Can view detalle venta', 9, 'view_detalleventa'),
(37, 'Can add direccion', 10, 'add_direccion'),
(38, 'Can change direccion', 10, 'change_direccion'),
(39, 'Can delete direccion', 10, 'delete_direccion'),
(40, 'Can view direccion', 10, 'view_direccion'),
(41, 'Can add lote', 11, 'add_lote'),
(42, 'Can change lote', 11, 'change_lote'),
(43, 'Can delete lote', 11, 'delete_lote'),
(44, 'Can view lote', 11, 'view_lote'),
(45, 'Can add nutricional', 12, 'add_nutricional'),
(46, 'Can change nutricional', 12, 'change_nutricional'),
(47, 'Can delete nutricional', 12, 'delete_nutricional'),
(48, 'Can view nutricional', 12, 'view_nutricional'),
(49, 'Can add producto', 13, 'add_producto'),
(50, 'Can change producto', 13, 'change_producto'),
(51, 'Can delete producto', 13, 'delete_producto'),
(52, 'Can view producto', 13, 'view_producto'),
(53, 'Can add rol', 14, 'add_rol'),
(54, 'Can change rol', 14, 'change_rol'),
(55, 'Can delete rol', 14, 'delete_rol'),
(56, 'Can view rol', 14, 'view_rol'),
(57, 'Can add venta', 15, 'add_venta'),
(58, 'Can change venta', 15, 'change_venta'),
(59, 'Can delete venta', 15, 'delete_venta'),
(60, 'Can view venta', 15, 'view_venta'),
(61, 'Can add regla alerta vencimiento', 16, 'add_reglaalertavencimiento'),
(62, 'Can change regla alerta vencimiento', 16, 'change_reglaalertavencimiento'),
(63, 'Can delete regla alerta vencimiento', 16, 'delete_reglaalertavencimiento'),
(64, 'Can view regla alerta vencimiento', 16, 'view_reglaalertavencimiento'),
(65, 'Can add producto regla alerta', 17, 'add_productoreglaalerta'),
(66, 'Can change producto regla alerta', 17, 'change_productoreglaalerta'),
(67, 'Can delete producto regla alerta', 17, 'delete_productoreglaalerta'),
(68, 'Can view producto regla alerta', 17, 'view_productoreglaalerta'),
(69, 'Can add pedido', 18, 'add_pedido'),
(70, 'Can change pedido', 18, 'change_pedido'),
(71, 'Can delete pedido', 18, 'delete_pedido'),
(72, 'Can view pedido', 18, 'view_pedido'),
(73, 'Can add detalle pedido', 19, 'add_detallepedido'),
(74, 'Can change detalle pedido', 19, 'change_detallepedido'),
(75, 'Can delete detalle pedido', 19, 'delete_detallepedido'),
(76, 'Can view detalle pedido', 19, 'view_detallepedido'),
(77, 'Can add notificacion', 20, 'add_notificacion'),
(78, 'Can change notificacion', 20, 'change_notificacion'),
(79, 'Can delete notificacion', 20, 'delete_notificacion'),
(80, 'Can view notificacion', 20, 'view_notificacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`, `descripcion`) VALUES
(21, 'Panadería', 'Pan fresco, artesanal y de masa madre.'),
(22, 'Pastelería', 'Pasteles, postres y bocadillos dulces.'),
(23, 'Cafetería y Bebidas', 'Café de grano, tés, jugos y más.'),
(24, 'Bocadillos y Salados', 'Empanadas, sándwiches y otras delicias saladas.'),
(25, 'Especiales de Temporada', 'Productos exclusivos por tiempo limitado.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `idclientes` int NOT NULL,
  PRIMARY KEY (`idclientes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle venta`
--

DROP TABLE IF EXISTS `detalle venta`;
CREATE TABLE IF NOT EXISTS `detalle venta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `venta_idventa` int NOT NULL,
  `Lote_idLote` int NOT NULL,
  `Lote_Productos_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

DROP TABLE IF EXISTS `direccion`;
CREATE TABLE IF NOT EXISTS `direccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calle` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `numero` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `depto` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `comuna` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `region` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `codigo_postal` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`id`, `calle`, `numero`, `depto`, `comuna`, `region`, `codigo_postal`) VALUES
(1, 'Poniente A', '375', '', 'Coquimbo', 'Coquimbo', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dispositivos_detallepedido`
--

DROP TABLE IF EXISTS `dispositivos_detallepedido`;
CREATE TABLE IF NOT EXISTS `dispositivos_detallepedido` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `producto_id` bigint NOT NULL,
  `pedido_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dispositivos_detallepedido_producto_id_e096b3e5` (`producto_id`),
  KEY `dispositivos_detallepedido_pedido_id_c92322df` (`pedido_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `dispositivos_detallepedido`
--

INSERT INTO `dispositivos_detallepedido` (`id`, `cantidad`, `precio`, `producto_id`, `pedido_id`) VALUES
(1, 5, 1200.00, 32, 1),
(2, 7, 15000.00, 33, 1),
(3, 4, 1200.00, 32, 2),
(4, 5, 15000.00, 33, 2),
(5, 5, 2500.00, 34, 2),
(6, 6, 3500.00, 35, 2),
(7, 5, 8000.00, 36, 2),
(8, 6, 2200.00, 39, 2),
(9, 6, 1800.00, 38, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dispositivos_notificacion`
--

DROP TABLE IF EXISTS `dispositivos_notificacion`;
CREATE TABLE IF NOT EXISTS `dispositivos_notificacion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `leido` tinyint(1) NOT NULL,
  `fecha_creacion` datetime(6) NOT NULL,
  `producto_id` bigint DEFAULT NULL,
  `usuario_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dispositivos_notificacion_producto_id_fc2d305f` (`producto_id`),
  KEY `dispositivos_notificacion_usuario_id_c3baaa89` (`usuario_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dispositivos_pedido`
--

DROP TABLE IF EXISTS `dispositivos_pedido`;
CREATE TABLE IF NOT EXISTS `dispositivos_pedido` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fecha_pedido` datetime(6) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `usuario_id` bigint NOT NULL,
  `estado` varchar(20) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dispositivos_pedido_usuario_id_d0e3aff9` (`usuario_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `dispositivos_pedido`
--

INSERT INTO `dispositivos_pedido` (`id`, `fecha_pedido`, `total`, `usuario_id`, `estado`) VALUES
(1, '2025-10-03 14:39:19.161335', 111000.00, 2, 'Pendiente'),
(2, '2025-10-04 00:28:46.470384', 177300.00, 2, 'Pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dispositivos_productoreglaalerta`
--

DROP TABLE IF EXISTS `dispositivos_productoreglaalerta`;
CREATE TABLE IF NOT EXISTS `dispositivos_productoreglaalerta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `producto_id` bigint NOT NULL,
  `regla_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dispositivos_productoreg_producto_id_regla_id_cfd6b878_uniq` (`producto_id`,`regla_id`),
  KEY `dispositivos_productoreglaalerta_producto_id_77882ca7` (`producto_id`),
  KEY `dispositivos_productoreglaalerta_regla_id_f0b0fc7a` (`regla_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dispositivos_reglaalertavencimiento`
--

DROP TABLE IF EXISTS `dispositivos_reglaalertavencimiento`;
CREATE TABLE IF NOT EXISTS `dispositivos_reglaalertavencimiento` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descripcion` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `dias_anticipacion` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `dispositivos_reglaalertavencimiento`
--

INSERT INTO `dispositivos_reglaalertavencimiento` (`id`, `nombre`, `descripcion`, `dias_anticipacion`) VALUES
(1, 'Vencimiento Crítico', 'Alerta para productos que vencen en 3 días o menos.', 3),
(2, 'Vencimiento Próximo', 'Alerta para productos que vencen en 7 días.', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `object_repr` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2025-10-03 14:32:04.114567', '1', 'dragcartvx2@gmail.com', 2, '[{\"changed\": {\"fields\": [\"Materno\"]}}]', 6, 1),
(2, '2025-10-03 14:32:13.784242', '2', 'joon243447@gmail.com', 2, '[{\"changed\": {\"fields\": [\"Roles\"]}}]', 6, 1),
(3, '2025-10-03 14:32:20.557475', '1', 'dragcartvx2@gmail.com', 2, '[{\"changed\": {\"fields\": [\"Roles\"]}}]', 6, 1),
(4, '2025-10-04 00:06:22.423911', '2', 'joon243447@gmail.com', 2, '[{\"changed\": {\"fields\": [\"Roles\"]}}]', 6, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'contenttypes', 'contenttype'),
(5, 'sessions', 'session'),
(6, 'dispositivos', 'usuario'),
(7, 'dispositivos', 'categoria'),
(8, 'dispositivos', 'cliente'),
(9, 'dispositivos', 'detalleventa'),
(10, 'dispositivos', 'direccion'),
(11, 'dispositivos', 'lote'),
(12, 'dispositivos', 'nutricional'),
(13, 'dispositivos', 'producto'),
(14, 'dispositivos', 'rol'),
(15, 'dispositivos', 'venta'),
(16, 'dispositivos', 'reglaalertavencimiento'),
(17, 'dispositivos', 'productoreglaalerta'),
(18, 'dispositivos', 'pedido'),
(19, 'dispositivos', 'detallepedido'),
(20, 'dispositivos', 'notificacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'dispositivos', '0001_initial', '2025-09-27 21:13:02.181790'),
(2, 'contenttypes', '0001_initial', '2025-09-27 21:13:02.212043'),
(3, 'admin', '0001_initial', '2025-09-27 21:13:02.355134'),
(4, 'admin', '0002_logentry_remove_auto_add', '2025-09-27 21:13:02.359327'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2025-09-27 21:13:02.361332'),
(6, 'contenttypes', '0002_remove_content_type_name', '2025-09-27 21:13:02.418048'),
(7, 'auth', '0001_initial', '2025-09-27 21:13:02.593412'),
(8, 'auth', '0002_alter_permission_name_max_length', '2025-09-27 21:13:02.622032'),
(9, 'auth', '0003_alter_user_email_max_length', '2025-09-27 21:13:02.629427'),
(10, 'auth', '0004_alter_user_username_opts', '2025-09-27 21:13:02.636480'),
(11, 'auth', '0005_alter_user_last_login_null', '2025-09-27 21:13:02.642733'),
(12, 'auth', '0006_require_contenttypes_0002', '2025-09-27 21:13:02.645730'),
(13, 'auth', '0007_alter_validators_add_error_messages', '2025-09-27 21:13:02.650729'),
(14, 'auth', '0008_alter_user_username_max_length', '2025-09-27 21:13:02.655728'),
(15, 'auth', '0009_alter_user_last_name_max_length', '2025-09-27 21:13:02.661049'),
(16, 'auth', '0010_alter_group_name_max_length', '2025-09-27 21:13:02.688213'),
(17, 'auth', '0011_update_proxy_permissions', '2025-09-27 21:13:02.700468'),
(18, 'auth', '0012_alter_user_first_name_max_length', '2025-09-27 21:13:02.705467'),
(19, 'sessions', '0001_initial', '2025-09-27 21:13:02.739580'),
(20, 'dispositivos', '0002_pedido_detallepedido', '2025-10-03 13:59:21.033588'),
(21, 'dispositivos', '0003_notificacion', '2025-10-03 14:17:33.597981'),
(22, 'dispositivos', '0004_crear_roles_iniciales', '2025-10-03 14:31:15.665658'),
(23, 'dispositivos', '0005_merge_0003_notificacion_0004_crear_roles_iniciales', '2025-10-03 14:31:15.666666'),
(24, 'dispositivos', '0006_pedido_estado', '2025-10-03 14:38:46.748165');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_session`
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('jc5728ygipnh1okp88oovnzq1jemzctv', '.eJxVjEEOgjAQRe_StWkYoMPUpXvP0ExnWosaSCisjHdXEha6_e-9_zKBt7WEraYljGrOBszpd4ssjzTtQO883WYr87QuY7S7Yg9a7XXW9Lwc7t9B4Vq-dUs5K2EvRIoRBJteoUvSMLIARXBucK1XHBILQetipxmz914IISbz_gDpujgX:1v2cHL:B9Z0wpF8uMrFv7yMBSE1jqpn_mCfGhUg9rHbwIDa70g', '2025-10-11 21:16:27.050307');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lote`
--

DROP TABLE IF EXISTS `lote`;
CREATE TABLE IF NOT EXISTS `lote` (
  `idLote` int NOT NULL,
  `Productos_id` int NOT NULL,
  PRIMARY KEY (`idLote`,`Productos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nutricional`
--

DROP TABLE IF EXISTS `nutricional`;
CREATE TABLE IF NOT EXISTS `nutricional` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ingredientes` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `tiempo_preparacion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `proteinas` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `azucar` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gluten` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `nutricional`
--

INSERT INTO `nutricional` (`id`, `ingredientes`, `tiempo_preparacion`, `proteinas`, `azucar`, `gluten`) VALUES
(11, 'Harina, agua, sal, levadura', '3 horas', '9g', '1g', 'Sí'),
(12, 'Harina, mantequilla, azúcar, huevo', '4 horas', '6g', '15g', 'Sí'),
(13, 'Chocolate, harina, azúcar, huevo, mantequilla', '2 horas', '8g', '40g', 'Sí'),
(14, 'Harina integral, semillas de girasol, linaza, sésamo', '4 horas', '12g', '2g', 'Sí'),
(15, 'Harina, masa madre, agua, sal', '24 horas', '10g', '1g', 'Sí'),
(16, 'Manzanas, canela, harina, mantequilla, azúcar', '1.5 horas', '4g', '30g', 'Sí'),
(17, 'Queso crema, galletas, limón, azúcar', '3 horas', '7g', '25g', 'Sí'),
(18, 'Café de grano arábica, agua caliente', '5 minutos', '0.1g', '0g', 'No'),
(19, 'Café, leche, espuma de leche', '7 minutos', '8g', '12g', 'No'),
(20, 'Té negro, especias (canela, cardamomo), leche, azúcar', '10 minutos', '7g', '20g', 'No'),
(21, 'Naranjas frescas exprimidas', '5 minutos', '1g', '22g', 'No'),
(22, 'Pan, jamón de pavo, queso, lechuga, tomate', '10 minutos', '25g', '5g', 'Sí'),
(23, 'Masa de hojaldre, espinacas, queso ricota', '25 minutos', '15g', '3g', 'Sí'),
(24, 'Harina, carne molida, cebolla, huevo', '45 minutos', '18g', '4g', 'Sí'),
(25, 'Zapallo, harina, especias, azúcar flor', '1 hora', '5g', '25g', 'Sí'),
(26, 'Harina, huevos, fruta confitada, frutos secos', '3 horas', '9g', '40g', 'Sí'),
(27, 'Avena, miel, frutos secos, semillas', '30 minutos', '10g', '18g', 'Puede contener'),
(28, 'Harina de almendras, azúcar glas, clara de huevo', '1 hora', '5g', '35g', 'No'),
(29, 'Chocolate negro, crema, mantequilla', '30 minutos', '3g', '20g', 'No'),
(30, 'Leche, huevos, azúcar, vainilla', '1 hora', '9g', '30g', 'No'),
(31, 'Harina de maíz, queso', '25 minutos', '12g', '2g', 'No'),
(32, 'Agua mineral con gas, limón', '1 minuto', '0g', '0g', 'No'),
(33, 'Harina, aceitunas, romero, aceite de oliva', '2.5 horas', '8g', '1g', 'Sí');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descripcion` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `marca` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `precio` int DEFAULT NULL,
  `caducidad` date NOT NULL,
  `elaboracion` date DEFAULT NULL,
  `tipo` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `Categorias_id` int NOT NULL,
  `stock_actual` int DEFAULT NULL,
  `stock_minimo` int DEFAULT NULL,
  `stock_maximo` int DEFAULT NULL,
  `presentacion` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `formato` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `Nutricional_id` int NOT NULL,
  `creado` timestamp NULL DEFAULT NULL,
  `modificado` timestamp NULL DEFAULT NULL,
  `eliminado` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `marca`, `precio`, `caducidad`, `elaboracion`, `tipo`, `Categorias_id`, `stock_actual`, `stock_minimo`, `stock_maximo`, `presentacion`, `formato`, `Nutricional_id`, `creado`, `modificado`, `eliminado`) VALUES
(32, 'Croissant de Mantequilla', 'Clásico croissant francés, laminado a la perfección.', 'La Fornería', 1200, '2025-10-06', '2025-10-04', 'Hojaldre', 22, 21, 5, 60, NULL, NULL, 12, NULL, NULL, NULL),
(33, 'Torta de Chocolate Belga', 'Torta intensa de chocolate belga con triple capa.', 'Pastelería Fina', 15000, '2025-10-10', '2025-10-03', 'Postre', 22, -2, 2, 15, NULL, NULL, 13, NULL, NULL, NULL),
(34, 'Pan Multigrano', 'Saludable pan con mezcla de 5 semillas.', 'La Fornería', 2500, '2025-10-08', '2025-10-03', 'Integral', 21, 35, 10, 80, NULL, NULL, 14, NULL, NULL, NULL),
(35, 'Hogaza de Masa Madre', 'Pan rústico de larga fermentación y gran sabor.', 'La Fornería', 3500, '2025-10-09', '2025-10-02', 'Masa Madre', 21, 14, 5, 40, NULL, NULL, 15, NULL, NULL, NULL),
(36, 'Kuchen de Manzana', 'Tradicional pastel de manzana y canela.', 'Pastelería Fina', 8000, '2025-10-08', '2025-10-03', 'Dulce', 22, 10, 3, 25, NULL, NULL, 16, NULL, NULL, NULL),
(37, 'Cheesecake de Frambuesa', 'Suave cheesecake con mermelada de frambuesa casera.', 'Pastelería Fina', 12000, '2025-10-09', '2025-10-03', 'Postre Frío', 22, 12, 2, 20, NULL, NULL, 17, NULL, NULL, NULL),
(38, 'Café Americano', 'Espresso doble diluido en agua caliente.', 'Café del Bueno', 1800, '2026-01-01', '2025-10-04', 'Bebida', 23, 94, 20, 200, NULL, NULL, 18, NULL, NULL, NULL),
(39, 'Capuccino Italiano', 'El balance perfecto entre café, leche y espuma.', 'Café del Bueno', 2200, '2026-01-01', '2025-10-04', 'Bebida', 23, 94, 20, 200, NULL, NULL, 19, NULL, NULL, NULL),
(40, 'Té Chai Latte', 'Té negro especiado con leche vaporizada.', 'Infusiones del Mundo', 2500, '2026-01-01', '2025-10-04', 'Bebida', 23, 80, 15, 150, NULL, NULL, 20, NULL, NULL, NULL),
(41, 'Jugo de Naranja Natural', 'Jugo recién exprimido, 100% natural.', 'La Fornería', 2000, '2025-10-05', '2025-10-04', 'Bebida Fría', 23, 50, 10, 100, NULL, NULL, 21, NULL, NULL, NULL),
(42, 'Sándwich Pavo-Queso', 'En pan de molde integral con lechuga y tomate.', 'La Fornería', 4500, '2025-10-06', '2025-10-04', 'Salado', 24, 25, 5, 50, NULL, NULL, 22, NULL, NULL, NULL),
(43, 'Triángulo de Espinaca-Ricota', 'Delicioso bocadillo de hojaldre relleno.', 'La Fornería', 1800, '2025-10-06', '2025-10-04', 'Salado', 24, 30, 10, 60, NULL, NULL, 23, NULL, NULL, NULL),
(44, 'Empanada de Pino', 'Clásica empanada chilena horneada.', 'Sabores Criollos', 2200, '2025-10-06', '2025-10-04', 'Salado', 24, 40, 10, 80, NULL, NULL, 24, NULL, NULL, NULL),
(45, 'Calzones Rotos (Porción)', 'Dulce tradicional de invierno, frito y esponjoso.', 'La Fornería', 2500, '2025-10-06', '2025-10-04', 'Fritura Dulce', 25, 20, 5, 40, NULL, NULL, 25, NULL, NULL, NULL),
(46, 'Pan de Pascua', 'Exclusivo de Navidad, con frutos secos y fruta confitada.', 'La Fornería', 7900, '2025-12-30', '2025-10-01', 'Dulce Navideño', 25, 50, 0, 100, NULL, NULL, 26, NULL, NULL, NULL),
(47, 'Barra de Granola Casera', 'Snack saludable con avena, miel y frutos secos.', 'La Fornería', 1500, '2025-11-15', '2025-10-02', 'Snack', 22, 60, 15, 120, NULL, NULL, 27, NULL, NULL, NULL),
(48, 'Macarons (Caja de 6)', 'Finos dulces franceses de distintos sabores.', 'Pastelería Fina', 6000, '2025-10-10', '2025-10-03', 'Dulce Fino', 22, 20, 5, 30, NULL, NULL, 28, NULL, NULL, NULL),
(49, 'Trufas de Chocolate', 'Bocadillos intensos de chocolate negro.', 'Pastelería Fina', 800, '2025-10-20', '2025-10-03', 'Chocolatería', 22, 50, 10, 100, NULL, NULL, 29, NULL, NULL, NULL),
(50, 'Leche Asada', 'Postre casero tradicional con caramelo.', 'La Fornería', 2000, '2025-10-08', '2025-10-03', 'Postre', 22, 25, 5, 40, NULL, NULL, 30, NULL, NULL, NULL),
(51, 'Chipa (Porción de 3)', 'Panecillos de queso y almidón de yuca.', 'Sabores Criollos', 1800, '2025-10-05', '2025-10-04', 'Salado Sin Gluten', 24, 30, 10, 50, NULL, NULL, 31, NULL, NULL, NULL),
(52, 'Agua con Gas y Limón', 'Bebida refrescante y sin azúcar.', 'Aguas del Sur', 1500, '2026-06-01', '2025-01-01', 'Bebida Fría', 23, 100, 20, 200, NULL, NULL, 32, NULL, NULL, NULL),
(53, 'Focaccia de Aceitunas', 'Pan plano italiano con aceitunas y romero.', 'La Fornería', 2800, '2025-10-06', '2025-10-03', 'Artesanal', 21, 20, 5, 35, NULL, NULL, 33, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `descripcion` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES
(1, 'Admin', 'Rol con permisos de administrador.'),
(2, 'Cliente', 'Rol para clientes que compran en la tienda.'),
(3, 'Usuario', 'Rol para usuarios generales del sistema.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `materno` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `run` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `fono` int DEFAULT NULL,
  `Direccion_id` int DEFAULT NULL,
  `Roles_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `run_UNIQUE` (`run`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `password`, `last_login`, `is_superuser`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `materno`, `run`, `fono`, `Direccion_id`, `Roles_id`) VALUES
(1, 'pbkdf2_sha256$1000000$7VD6DU2J6lPkcy4KlGhDDw$Kp0WpMJv9QUr0gY9H83N84DGeWa/4get3lSMGUlhles=', '2025-10-04 00:28:55.220373', 1, 'sebastian', 'madrid', 'dragcartvx2@gmail.com', 1, 1, '2025-09-27 21:16:06.000000', 'abalos', '216884647', NULL, NULL, 1),
(2, 'pbkdf2_sha256$1000000$sH5B94FkmwgcxivDMXAyL3$9rTpv/334VKLEFy6zeuv25XBZJYMjhilU3hHFcGKdOw=', '2025-10-04 00:28:02.919485', 0, 'sebastian', 'mauricio', 'joon243447@gmail.com', 0, 1, '2025-10-03 14:22:12.000000', 'abalos', '21688464-7', 988976746, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

DROP TABLE IF EXISTS `venta`;
CREATE TABLE IF NOT EXISTS `venta` (
  `idventa` int NOT NULL AUTO_INCREMENT,
  `Usuarios_id` int NOT NULL,
  `EstadoPedido` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `clientes_idclientes` int NOT NULL,
  PRIMARY KEY (`idventa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
